exports.index = function* () {
    this.body = 'hello world!';
}
exports.index.method = 'get';