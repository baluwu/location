exports.index = function* () {
    this.body = 'shop:deal/,deal/index,deal/index/index';
}
exports.order = function* () {
    this.body = 'shop:deal/index/order';
}